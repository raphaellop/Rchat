-- RCHAT 4.0 PLUS — installation additive
-- A executer dans Supabase > SQL Editor du projet iqqllfcwdisomsyypeuu.
-- Ce script ne supprime aucune table ni aucun message existant.

create table if not exists public.rchat3_premium (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text not null default 'inactive' check (status in ('active','inactive','revoked')),
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.rchat3_premium enable row level security;
drop policy if exists "rchat3_plus_read_authenticated" on public.rchat3_premium;
create policy "rchat3_plus_read_authenticated" on public.rchat3_premium for select to authenticated using (true);
grant select on public.rchat3_premium to authenticated;

create or replace function public.rchat3_has_active_plus(p_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.rchat3_premium p where p.user_id=p_user_id and p.status='active' and p.expires_at>now()); $$;
revoke all on function public.rchat3_has_active_plus(uuid) from public;
grant execute on function public.rchat3_has_active_plus(uuid) to authenticated;

create or replace function public.rchat3_set_plus(p_user_id uuid,p_days integer)
returns timestamptz language plpgsql security definer set search_path=public
as $$
declare v_exp timestamptz;
begin
 if auth.uid() is null then raise exception 'Connexion requise.'; end if;
 if p_days not in (30,90,180,365) then raise exception 'Durée non autorisée.'; end if;
 if not exists(select 1 from public.rchat3_staff s where s.user_id=auth.uid() and s.role='admin') then raise exception 'Droits administrateur requis.'; end if;
 insert into public.rchat3_premium(user_id,status,expires_at)
 values(p_user_id,'active',now()+make_interval(days=>p_days))
 on conflict(user_id) do update set status='active',expires_at=greatest(coalesce(public.rchat3_premium.expires_at,now()),now())+make_interval(days=>p_days);
 select expires_at into v_exp from public.rchat3_premium where user_id=p_user_id;
 return v_exp;
end $$;
revoke all on function public.rchat3_set_plus(uuid,integer) from public;
grant execute on function public.rchat3_set_plus(uuid,integer) to authenticated;

create table if not exists public.rchat3_plus_identity (
 user_id uuid primary key references auth.users(id) on delete cascade,
 name_color text not null default '#d9baff' check(name_color in ('#d9baff','#78efff','#9cffd5','#ffd58a','#ff9fc9','#ffffff')),
 avatar_frame text not null default 'none' check(avatar_frame in ('none','glow','orbit','gold')),
 profile_effect text not null default 'none' check(profile_effect in ('none','soft-glow','neon')),
 updated_at timestamptz not null default now()
);
alter table public.rchat3_plus_identity enable row level security;
drop policy if exists "rchat3_plus_identity_read" on public.rchat3_plus_identity;
create policy "rchat3_plus_identity_read" on public.rchat3_plus_identity for select to authenticated using(true);
drop policy if exists "rchat3_plus_identity_insert_own" on public.rchat3_plus_identity;
create policy "rchat3_plus_identity_insert_own" on public.rchat3_plus_identity for insert to authenticated with check(user_id=auth.uid() and public.rchat3_has_active_plus(auth.uid()));
drop policy if exists "rchat3_plus_identity_update_own" on public.rchat3_plus_identity;
create policy "rchat3_plus_identity_update_own" on public.rchat3_plus_identity for update to authenticated using(user_id=auth.uid() and public.rchat3_has_active_plus(auth.uid())) with check(user_id=auth.uid() and public.rchat3_has_active_plus(auth.uid()));
grant select,insert,update on public.rchat3_plus_identity to authenticated;

-- Metadonnees de pieces jointes dans les messages existants.
alter table public.rchat3_messages add column if not exists attachment_path text;
alter table public.rchat3_messages add column if not exists attachment_name text;
alter table public.rchat3_messages add column if not exists attachment_type text;
alter table public.rchat3_messages add column if not exists attachment_size bigint;
grant insert (channel_id,author_id,content,attachment_path,attachment_name,attachment_type,attachment_size) on public.rchat3_messages to authenticated;

-- Bucket prive : les fichiers sont servis par URL signee, pas par URL publique.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('rchat3-chat-files','rchat3-chat-files',false,15728640,
 array['application/pdf','image/png','image/jpeg','image/webp','image/gif','text/plain','text/csv','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/msword','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.ms-powerpoint','video/mp4','video/quicktime'])
on conflict(id) do update set public=false,file_size_limit=15728640,allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "rchat3_chat_files_read_auth" on storage.objects;
create policy "rchat3_chat_files_read_auth" on storage.objects for select to authenticated using(bucket_id='rchat3-chat-files');
drop policy if exists "rchat3_chat_files_insert_own" on storage.objects;
create policy "rchat3_chat_files_insert_own" on storage.objects for insert to authenticated with check(bucket_id='rchat3-chat-files' and split_part(name,'/',2)=auth.uid()::text and public.rchat3_has_active_plus(auth.uid()));
drop policy if exists "rchat3_chat_files_delete_own" on storage.objects;
create policy "rchat3_chat_files_delete_own" on storage.objects for delete to authenticated using(bucket_id='rchat3-chat-files' and split_part(name,'/',2)=auth.uid()::text);

select 'Rchat 4.0 Plus : installation terminee' as resultat;
